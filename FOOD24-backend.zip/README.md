# FOOD24 IA — Backend MVP

FastAPI + PostgreSQL (+ PostGIS/pgvector en fases posteriores).

## Estructura

```
food24/
├── app/
│   ├── core/          # config, database, security
│   ├── models/        # SQLAlchemy
│   ├── schemas/       # Pydantic
│   ├── api/v1/        # routers
│   ├── services/      # vector_service (stub IA)
│   └── main.py
├── sql/schema.sql
├── alembic/
├── requirements.txt
└── .env.example
```

## Arranque (PC / VPS — no Termux para el stack completo)

```bash
cd food24
python -m venv .venv
source .venv/bin/activate   # Windows: .venv\Scripts\activate
pip install -r requirements.txt
pip install 'python-jose[cryptography]' passlib[bcrypt] email-validator

cp .env.example .env
# editar .env

# PostgreSQL: crear DB y aplicar schema
psql -U postgres -c "CREATE USER food24 WITH PASSWORD 'strongpassword';"
psql -U postgres -c "CREATE DATABASE food24 OWNER food24;"
psql -U food24 -d food24 -f sql/schema.sql

uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
```

Docs: http://localhost:8000/docs

## Endpoints MVP

| Método | Ruta | Descripción |
|--------|------|-------------|
| GET | `/api/v1/health` | Health |
| POST | `/api/v1/auth/register` | Registro |
| POST | `/api/v1/auth/login` | Login JWT |
| GET | `/api/v1/restaurants` | Listar |
| GET | `/api/v1/restaurants/{id}/menu` | Menú |
| POST | `/api/v1/orders` | Crear pedido |
| PATCH | `/api/v1/orders/{id}/status` | Estado |

## Fases siguientes

1. JWT Depends en pedidos
2. PostGIS (ubicación restaurantes/drivers)
3. Redis + WebSocket (chat / tracking)
4. pgvector + VectorService
5. S3 media upload

## PWA

Conectar con HOLOOS-Delivery-APK-Ready.zip (Netlify / PWABuilder).
