"""FOOD24 IA — Backend FastAPI"""
