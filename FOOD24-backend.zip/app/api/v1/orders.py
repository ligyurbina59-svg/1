from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from app.core.database import get_db
from app.models.order import Order, OrderItem
from app.schemas.order import OrderCreate, OrderOut

router = APIRouter(prefix="/orders", tags=["orders"])


@router.post("", response_model=OrderOut)
async def create_order(body: OrderCreate, client_id: int = 1, db: AsyncSession = Depends(get_db)):
    """MVP: client_id fijo=1 hasta cablear JWT en Depends."""
    total = sum(i.unit_price * i.quantity for i in body.items)
    order = Order(
        client_id=client_id,
        restaurant_id=body.restaurant_id,
        status="pending",
        total=total,
        delivery_address=body.delivery_address,
        delivery_lat=body.delivery_lat,
        delivery_lng=body.delivery_lng,
    )
    db.add(order)
    await db.flush()
    for i in body.items:
        db.add(
            OrderItem(
                order_id=order.id,
                menu_item_id=i.menu_item_id,
                name=i.name,
                unit_price=i.unit_price,
                quantity=i.quantity,
            )
        )
    await db.flush()
    await db.refresh(order)
    return order


@router.get("/{order_id}", response_model=OrderOut)
async def get_order(order_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Order).where(Order.id == order_id))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Order not found")
    return order


@router.patch("/{order_id}/status")
async def update_status(order_id: int, status: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Order).where(Order.id == order_id))
    order = result.scalar_one_or_none()
    if not order:
        raise HTTPException(404, "Order not found")
    order.status = status
    await db.flush()
    return {"id": order.id, "status": order.status}
