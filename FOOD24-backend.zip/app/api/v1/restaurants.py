from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from sqlalchemy.orm import selectinload
from app.core.database import get_db
from app.models.restaurant import Restaurant, MenuItem
from app.schemas.restaurant import RestaurantOut, RestaurantCreate, MenuItemOut

router = APIRouter(prefix="/restaurants", tags=["restaurants"])


@router.get("", response_model=list[RestaurantOut])
async def list_restaurants(category: str | None = None, db: AsyncSession = Depends(get_db)):
    stmt = select(Restaurant).where(Restaurant.is_open.is_(True))
    if category and category != "all":
        stmt = stmt.where(Restaurant.category == category)
    result = await db.execute(stmt)
    return result.scalars().all()


@router.get("/{restaurant_id}", response_model=RestaurantOut)
async def get_restaurant(restaurant_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(select(Restaurant).where(Restaurant.id == restaurant_id))
    r = result.scalar_one_or_none()
    if not r:
        raise HTTPException(404, "Restaurant not found")
    return r


@router.get("/{restaurant_id}/menu", response_model=list[MenuItemOut])
async def get_menu(restaurant_id: int, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(MenuItem).where(MenuItem.restaurant_id == restaurant_id, MenuItem.is_available.is_(True))
    )
    return result.scalars().all()


@router.post("", response_model=RestaurantOut)
async def create_restaurant(body: RestaurantCreate, db: AsyncSession = Depends(get_db)):
    r = Restaurant(**body.model_dump())
    db.add(r)
    await db.flush()
    await db.refresh(r)
    return r
