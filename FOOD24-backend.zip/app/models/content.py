"""
Embeddings para pgvector (Fase IA).
Requiere: CREATE EXTENSION vector; y paquete pgvector.
Descomenta Vector cuando instales pgvector.
"""
from datetime import datetime
from sqlalchemy import String, Text, Integer, Float, DateTime, ForeignKey
from sqlalchemy.orm import Mapped, mapped_column
from sqlalchemy.sql import func
from app.core.database import Base

# from pgvector.sqlalchemy import Vector


class ContentEmbedding(Base):
    __tablename__ = "content_embeddings"

    id: Mapped[int] = mapped_column(primary_key=True)
    content_type: Mapped[str] = mapped_column(String(50), index=True)
    content_id: Mapped[int] = mapped_column(Integer, index=True)
    title: Mapped[str] = mapped_column(String(255))
    description: Mapped[str | None] = mapped_column(Text)
    # embedding: Mapped[list[float]] = mapped_column(Vector(384))
    social_cause_id: Mapped[int | None] = mapped_column(ForeignKey("social_causes.id"), nullable=True)
    popularity_score: Mapped[float] = mapped_column(Float, default=0.0)
    created_at: Mapped[datetime] = mapped_column(DateTime(timezone=True), server_default=func.now())
