from pydantic import BaseModel


class OrderItemIn(BaseModel):
    menu_item_id: int | None = None
    name: str
    unit_price: float
    quantity: int = 1


class OrderCreate(BaseModel):
    restaurant_id: int
    items: list[OrderItemIn]
    delivery_address: str | None = None
    delivery_lat: float | None = None
    delivery_lng: float | None = None


class OrderOut(BaseModel):
    id: int
    client_id: int
    restaurant_id: int
    driver_id: int | None
    status: str
    total: float
    delivery_address: str | None

    class Config:
        from_attributes = True
