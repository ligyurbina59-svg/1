from pydantic import BaseModel


class MenuItemOut(BaseModel):
    id: int
    name: str
    description: str | None = None
    price: float
    is_available: bool

    class Config:
        from_attributes = True


class RestaurantOut(BaseModel):
    id: int
    name: str
    description: str | None = None
    category: str
    rating: float
    delivery_fee: float
    eta_min: int
    eta_max: int
    is_open: bool
    lat: float | None = None
    lng: float | None = None

    class Config:
        from_attributes = True


class RestaurantCreate(BaseModel):
    name: str
    description: str | None = None
    category: str = "general"
    delivery_fee: float = 1.5
    eta_min: int = 25
    eta_max: int = 40
    lat: float | None = None
    lng: float | None = None
