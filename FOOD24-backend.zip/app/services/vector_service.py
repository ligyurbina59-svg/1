"""
Servicio de embeddings + pgvector (Fase IA).
Instalar: pip install sentence-transformers pgvector
Y en PostgreSQL: CREATE EXTENSION vector;
"""
from typing import List, Any


class VectorService:
    """Stub listo para activar cuando el modelo y pgvector estén disponibles."""

    def __init__(self, db: Any):
        self.db = db
        self._model = None

    def _get_model(self):
        if self._model is None:
            from sentence_transformers import SentenceTransformer
            self._model = SentenceTransformer("all-MiniLM-L6-v2")
        return self._model

    def generate_embedding(self, text: str) -> List[float]:
        model = self._get_model()
        emb = model.encode(text, normalize_embeddings=True)
        return emb.tolist()

    async def store_embedding(self, **kwargs):
        raise NotImplementedError("Activa ContentEmbedding.embedding (Vector) y pgvector primero")

    async def semantic_search(self, query: str, limit: int = 10, **kwargs):
        raise NotImplementedError("Activa pgvector + índice HNSW primero")
