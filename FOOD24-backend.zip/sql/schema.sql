-- FOOD24 IA — schema base (MVP)
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    email VARCHAR(255) UNIQUE NOT NULL,
    username VARCHAR(80) UNIQUE NOT NULL,
    hashed_password VARCHAR(255) NOT NULL,
    role VARCHAR(30) DEFAULT 'client',
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS restaurants (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    category VARCHAR(50) DEFAULT 'general',
    rating FLOAT DEFAULT 5.0,
    delivery_fee FLOAT DEFAULT 1.5,
    eta_min INT DEFAULT 25,
    eta_max INT DEFAULT 40,
    is_open BOOLEAN DEFAULT TRUE,
    owner_id INT REFERENCES users(id),
    lat FLOAT,
    lng FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS menu_items (
    id SERIAL PRIMARY KEY,
    restaurant_id INT NOT NULL REFERENCES restaurants(id) ON DELETE CASCADE,
    name VARCHAR(150) NOT NULL,
    description TEXT,
    price FLOAT NOT NULL,
    is_available BOOLEAN DEFAULT TRUE
);

CREATE TABLE IF NOT EXISTS orders (
    id SERIAL PRIMARY KEY,
    client_id INT NOT NULL REFERENCES users(id),
    restaurant_id INT NOT NULL REFERENCES restaurants(id),
    driver_id INT REFERENCES users(id),
    status VARCHAR(40) DEFAULT 'pending',
    total FLOAT DEFAULT 0,
    delivery_address TEXT,
    delivery_lat FLOAT,
    delivery_lng FLOAT,
    created_at TIMESTAMPTZ DEFAULT NOW(),
    updated_at TIMESTAMPTZ DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS order_items (
    id SERIAL PRIMARY KEY,
    order_id INT NOT NULL REFERENCES orders(id) ON DELETE CASCADE,
    menu_item_id INT REFERENCES menu_items(id),
    name VARCHAR(150) NOT NULL,
    unit_price FLOAT NOT NULL,
    quantity INT DEFAULT 1
);

CREATE TABLE IF NOT EXISTS social_causes (
    id SERIAL PRIMARY KEY,
    name VARCHAR(150) UNIQUE NOT NULL,
    description TEXT,
    image_url VARCHAR(500),
    is_active BOOLEAN DEFAULT TRUE,
    total_raised FLOAT DEFAULT 0,
    created_at TIMESTAMPTZ DEFAULT NOW()
);
