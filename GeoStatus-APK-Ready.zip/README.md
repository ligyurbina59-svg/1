# Geo Status App

App móvil (PWA) que consume tu API de geo-blocking:

- `GET /api/geo-status`
- `GET /api/countries-map`

## Uso

1. Abre la app
2. (Opcional) Escribe la URL base de tu servidor Express y pulsa Guardar
3. Si dejas la URL vacía, funciona en **modo demo**

## Generar APK

1. Publica esta carpeta en HTTPS (GitHub Pages, Netlify...)
2. Ve a https://www.pwabuilder.com
3. Package → Android → Descarga el APK
