// Geo Status App — consume /api/geo-status y /api/countries-map

const DEMO_ALLOWED = ['US','CA','MX','ES','AR','CL','CO','PE','UY','CR','PA','EC','BO','PY','GT','HN','SV','NI','DO','PR'];
const DEMO_BLOCKED = ['RU','CN','KP','IR','SY','CU','VE'];
const COUNTRY_NAMES = {
  US:'Estados Unidos', CA:'Canadá', MX:'México', ES:'España', AR:'Argentina',
  CL:'Chile', CO:'Colombia', PE:'Perú', UY:'Uruguay', CR:'Costa Rica',
  PA:'Panamá', EC:'Ecuador', BO:'Bolivia', PY:'Paraguay', GT:'Guatemala',
  HN:'Honduras', SV:'El Salvador', NI:'Nicaragua', DO:'Rep. Dominicana', PR:'Puerto Rico',
  RU:'Rusia', CN:'China', KP:'Corea del Norte', IR:'Irán', SY:'Siria',
  CU:'Cuba', VE:'Venezuela', BR:'Brasil', FR:'Francia', DE:'Alemania',
  GB:'Reino Unido', IT:'Italia', JP:'Japón', KR:'Corea del Sur', IN:'India'
};

function getName(code) {
  return COUNTRY_NAMES[code] || code;
}

function getApiBase() {
  return localStorage.getItem('geo_api_base') || '';
}

function setApiBase(url) {
  localStorage.setItem('geo_api_base', url.trim().replace(/\/$/, ''));
}

async function fetchGeoStatus() {
  const base = getApiBase();
  if (!base) {
    // Demo mode
    return {
      clientCountry: 'MX',
      clientIP: '0.0.0.0 (demo)',
      allowed: true,
      timestamp: new Date().toISOString(),
      allowedCountries: DEMO_ALLOWED,
      blockedCountries: DEMO_BLOCKED,
      demo: true
    };
  }
  const res = await fetch(`${base}/api/geo-status`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

async function fetchCountriesMap() {
  const base = getApiBase();
  if (!base) {
    return {
      allowed: DEMO_ALLOWED.map(code => ({ code, name: getName(code), status: 'allowed', color: '#22c55e' })),
      blocked: DEMO_BLOCKED.map(code => ({ code, name: getName(code), status: 'blocked', color: '#ef4444' }))
    };
  }
  const res = await fetch(`${base}/api/countries-map`);
  if (!res.ok) throw new Error(`HTTP ${res.status}`);
  return res.json();
}

function renderStatus(data) {
  const card = document.getElementById('status-card');
  const icon = document.getElementById('status-icon');
  const title = document.getElementById('status-title');
  const desc = document.getElementById('status-desc');
  const meta = document.getElementById('status-meta');

  card.classList.remove('allowed', 'blocked', 'unknown');

  if (data.allowed === true) {
    card.classList.add('allowed');
    icon.textContent = '✅';
    title.textContent = 'Acceso permitido';
    desc.textContent = data.demo ? 'Modo demostración' : 'Tu país está en la lista de permitidos';
  } else if (data.allowed === false && data.clientCountry) {
    card.classList.add('blocked');
    icon.textContent = '🚫';
    title.textContent = 'Acceso bloqueado';
    desc.textContent = 'Tu país no tiene acceso a este servicio';
  } else {
    card.classList.add('unknown');
    icon.textContent = '❓';
    title.textContent = 'Estado desconocido';
    desc.textContent = 'No se pudo determinar el país';
  }

  meta.innerHTML = `
    <span>País: <strong>${data.clientCountry || '—'} ${data.clientCountry ? '(' + getName(data.clientCountry) + ')' : ''}</strong></span>
    <span>IP: ${data.clientIP || '—'}</span>
    <span>Hora: ${data.timestamp ? new Date(data.timestamp).toLocaleString() : '—'}</span>
    ${data.demo ? '<span style="color:#f59e0b">Modo demo (sin API)</span>' : ''}
  `;
}

let currentTab = 'allowed';
let countriesData = { allowed: [], blocked: [] };

function renderCountries() {
  const list = document.getElementById('countries-list');
  const items = currentTab === 'allowed' ? countriesData.allowed : countriesData.blocked;

  if (!items || items.length === 0) {
    list.innerHTML = '<p class="empty">No hay países en esta lista</p>';
    return;
  }

  list.innerHTML = items.map(c => `
    <div class="country-item">
      <span class="country-dot" style="background:${c.color || (c.status === 'allowed' ? '#22c55e' : '#ef4444')}"></span>
      <span class="code">${c.code}</span>
      <span class="name">${c.name || getName(c.code)}</span>
    </div>
  `).join('');
}

async function loadAll() {
  document.getElementById('status-title').textContent = 'Comprobando...';
  document.getElementById('status-icon').textContent = '⏳';
  document.getElementById('countries-list').innerHTML = '<p class="loading">Cargando...</p>';

  try {
    const [status, map] = await Promise.all([fetchGeoStatus(), fetchCountriesMap()]);
    renderStatus(status);
    countriesData = map;
    renderCountries();
  } catch (err) {
    document.getElementById('status-icon').textContent = '⚠️';
    document.getElementById('status-title').textContent = 'Error de conexión';
    document.getElementById('status-desc').textContent = err.message;
    document.getElementById('status-card').classList.add('unknown');
    document.getElementById('countries-list').innerHTML = '<p class="empty">No se pudo cargar la lista</p>';
  }
}

// Events
document.getElementById('btn-refresh').addEventListener('click', loadAll);

document.getElementById('btn-save-api').addEventListener('click', () => {
  const url = document.getElementById('api-base').value;
  setApiBase(url);
  loadAll();
});

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(t => t.classList.remove('active'));
    tab.classList.add('active');
    currentTab = tab.dataset.tab;
    renderCountries();
  });
});

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const view = item.dataset.view;
    if (view === 'info') {
      alert('Geo Status App\n\nConecta la URL de tu API Express (/api/geo-status y /api/countries-map).\nSi dejas la URL vacía, usa datos de demostración.');
    }
  });
});

// Init
document.getElementById('api-base').value = getApiBase();
loadAll();

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}
