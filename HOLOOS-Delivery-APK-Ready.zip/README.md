# HOLOOS Delivery

App dual:
- Cliente: pedir comida (restaurantes, carrito, pedidos)
- Driver: en línea, pedidos asignados, términos

## APK
Publica en HTTPS → https://www.pwabuilder.com → Package → Android

Repo sugerido: ligyurbina59-svg/holoos-delivery
URL: https://ligyurbina59-svg.github.io/holoos-delivery/
