const RESTOS = [
  { id: 1, name: 'Burger House', cat: 'burger', emoji: '🍔', rating: 4.8, time: '25-35 min', fee: '$1.50',
    menu: [{ name: 'Classic Burger', price: 8.5 }, { name: 'Double Smash', price: 11 }, { name: 'Papas', price: 3.5 }] },
  { id: 2, name: 'Pizza Roma', cat: 'pizza', emoji: '🍕', rating: 4.6, time: '30-40 min', fee: '$2.00',
    menu: [{ name: 'Margarita', price: 9 }, { name: 'Pepperoni', price: 10.5 }, { name: '4 Quesos', price: 11.5 }] },
  { id: 3, name: 'Sushi Nikkei', cat: 'sushi', emoji: '🍣', rating: 4.9, time: '35-45 min', fee: '$2.50',
    menu: [{ name: 'Combo 12 pzs', price: 14 }, { name: 'Philadelphia', price: 7.5 }, { name: 'Miso', price: 3 }] },
  { id: 4, name: 'Taco Loco', cat: 'tacos', emoji: '🌮', rating: 4.5, time: '20-30 min', fee: '$1.00',
    menu: [{ name: 'Pastor (3)', price: 6.5 }, { name: 'Quesadilla', price: 5.5 }, { name: 'Guacamole', price: 4 }] }
];

const TERMS = `
  <h3>Términos del Driver</h3>
  <p>Al activar "En línea" aceptas estos términos.</p>
  <h3>1. Independiente</h3>
  <p>Eres prestador de servicios independiente, no empleado de HOLOOS.</p>
  <h3>2. Obligaciones</h3>
  <ul>
    <li>Documentación vigente (licencia, identificación)</li>
    <li>Respetar tránsito y normas de higiene</li>
    <li>Entregar pedidos sin alterarlos</li>
  </ul>
  <h3>3. Pagos</h3>
  <p>Tarifa por distancia y demanda. Comisión de plataforma aplicable.</p>
  <h3>4. Cancelaciones</h3>
  <p>Cancelaciones frecuentes pueden reducir prioridad de asignación.</p>
  <button class="checkout" id="accept-terms">Acepto los términos</button>
`;

let cart = JSON.parse(localStorage.getItem('hd_cart') || '[]');
let cat = 'all';
let isDriver = false;

function saveCart() {
  localStorage.setItem('hd_cart', JSON.stringify(cart));
}

function renderRestos(q = '') {
  const list = document.getElementById('resto-list');
  let items = RESTOS.filter(r => cat === 'all' || r.cat === cat);
  if (q) {
    const s = q.toLowerCase();
    items = items.filter(r => r.name.toLowerCase().includes(s) || r.menu.some(m => m.name.toLowerCase().includes(s)));
  }
  list.innerHTML = items.map(r => `
    <button class="resto" data-id="${r.id}">
      <div class="resto-emoji">${r.emoji}</div>
      <div>
        <h3>${r.name}</h3>
        <p>${r.menu[0].name}…</p>
        <div class="meta">⭐ ${r.rating} · ${r.time} · Envío ${r.fee}</div>
      </div>
    </button>
  `).join('') || '<p style="color:#94a3b8;text-align:center;padding:20px">Sin resultados</p>';
  list.querySelectorAll('.resto').forEach(b => b.addEventListener('click', () => openResto(+b.dataset.id)));
}

function openResto(id) {
  const r = RESTOS.find(x => x.id === id);
  if (!r) return;
  openPanel(r.name, `
    <div style="text-align:center;margin-bottom:12px;font-size:40px">${r.emoji}</div>
    <p style="text-align:center;color:#94a3b8;font-size:12px;margin-bottom:12px">⭐ ${r.rating} · ${r.time} · ${r.fee}</p>
    ${r.menu.map((m, i) => `
      <div class="menu-item">
        <div><strong>${m.name}</strong><br><span style="color:#f97316">$${m.price.toFixed(2)}</span></div>
        <button class="add-btn" data-r="${r.id}" data-i="${i}">+</button>
      </div>
    `).join('')}
  `);
  document.querySelectorAll('.add-btn').forEach(btn => {
    btn.addEventListener('click', () => {
      const resto = RESTOS.find(x => x.id === +btn.dataset.r);
      const item = resto.menu[+btn.dataset.i];
      const key = resto.id + '-' + item.name;
      const ex = cart.find(c => c.key === key);
      if (ex) ex.qty++; else cart.push({ key, name: item.name, resto: resto.name, price: item.price, qty: 1 });
      saveCart();
      btn.textContent = '✓';
      setTimeout(() => btn.textContent = '+', 500);
    });
  });
}

function openCart() {
  if (!cart.length) { openPanel('Carrito', '<p style="color:#94a3b8;text-align:center;padding:24px">Carrito vacío</p>'); return; }
  const total = cart.reduce((s, i) => s + i.price * i.qty, 0);
  openPanel('Carrito', cart.map(i => `
    <div class="menu-item"><span>${i.qty}× ${i.name}</span><span>$${(i.price*i.qty).toFixed(2)}</span></div>
  `).join('') + `
    <div class="menu-item"><strong>Total</strong><strong>$${total.toFixed(2)}</strong></div>
    <button class="checkout" id="do-order">Hacer pedido</button>
  `);
  document.getElementById('do-order')?.addEventListener('click', () => {
    alert('Pedido enviado (demo)\nTotal: $' + total.toFixed(2) + '\nUn driver lo recogerá pronto.');
    cart = []; saveCart();
    document.getElementById('panel').classList.add('hidden');
  });
}

function openPanel(title, html) {
  document.getElementById('panel-title').textContent = title;
  document.getElementById('panel-body').innerHTML = html;
  document.getElementById('panel').classList.remove('hidden');
  document.getElementById('accept-terms')?.addEventListener('click', () => {
    localStorage.setItem('hd_terms', '1');
    alert('Términos aceptados');
    document.getElementById('panel').classList.add('hidden');
  });
}

document.getElementById('panel-close').addEventListener('click', () => {
  document.getElementById('panel').classList.add('hidden');
});

document.getElementById('mode-btn').addEventListener('click', () => {
  isDriver = !isDriver;
  document.getElementById('client-view').classList.toggle('hidden', isDriver);
  document.getElementById('driver-view').classList.toggle('hidden', !isDriver);
  document.getElementById('client-nav').classList.toggle('hidden', isDriver);
  document.getElementById('mode-label').textContent = isDriver ? 'Modo Driver' : 'Modo Cliente';
  document.getElementById('mode-btn').textContent = isDriver ? 'Soy Cliente' : 'Soy Driver';
});

document.getElementById('online-toggle').addEventListener('change', e => {
  if (e.target.checked && !localStorage.getItem('hd_terms')) {
    e.target.checked = false;
    openPanel('Términos', TERMS);
    return;
  }
  const on = e.target.checked;
  document.getElementById('online-title').textContent = on ? 'En línea' : 'Desconectado';
  document.getElementById('online-desc').textContent = on ? 'Recibiendo pedidos' : 'Activa para recibir pedidos';
  const job = document.getElementById('job-card');
  if (on) {
    job.classList.add('active');
    job.innerHTML = `
      <div style="color:#f97316;font-size:12px;margin-bottom:6px">#ORD-1042 · Demo</div>
      <h3>Burger House → Calle 12 #45</h3>
      <p>2.3 km · $4.50 · ~15 min</p>
    `;
    document.getElementById('s-orders').textContent = '3';
    document.getElementById('s-money').textContent = '$18';
  } else {
    job.classList.remove('active');
    job.innerHTML = `<h3>Sin pedido activo</h3><p>Los pedidos aparecerán aquí cuando estés en línea.</p>`;
  }
});

document.getElementById('btn-terms').addEventListener('click', () => openPanel('Términos', TERMS));

document.querySelectorAll('.cat').forEach(b => {
  b.addEventListener('click', () => {
    document.querySelectorAll('.cat').forEach(c => c.classList.remove('active'));
    b.classList.add('active');
    cat = b.dataset.cat;
    renderRestos(document.getElementById('search').value);
  });
});

document.getElementById('search').addEventListener('input', e => renderRestos(e.target.value));

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const t = item.dataset.tab;
    if (t === 'cart') openCart();
    if (t === 'orders') openPanel('Pedidos', `
      <div class="menu-row" style="background:#1e293b;padding:12px;border-radius:12px;border:1px solid rgba(249,115,22,.3)">
        <div style="color:#f97316;font-size:12px">#ORD-2041 · En camino</div>
        <strong>Burger House</strong>
        <div style="color:#94a3b8;font-size:12px;margin-top:4px">🛵 Driver asignado · ~12 min</div>
      </div>
    `);
    if (t === 'account') openPanel('Cuenta', `
      <p style="color:#94a3b8">Cliente HOLOOS Delivery</p>
      <div style="background:#1e293b;padding:12px;border-radius:12px;margin-top:8px">
        <strong>Dirección</strong><br><span style="color:#94a3b8;font-size:13px">Calle 12 #45-67 (demo)</span>
      </div>
    `);
  });
});

renderRestos();
if ('serviceWorker' in navigator) navigator.serviceWorker.register('./sw.js').catch(() => {});
