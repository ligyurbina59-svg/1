# HOLOOS Super App

App multifuncional que unifica:
- Home (hub)
- Memory Graph
- MobilityOS
- Messenger
- AI Assistant
- Spatial XR
- Bio Engine
- Panel de Control

## Generar APK

1. Sube esta carpeta a un hosting HTTPS (GitHub Pages, Netlify, etc.)
2. Ve a https://www.pwabuilder.com
3. Pega la URL → Package → Android → Descarga el APK
