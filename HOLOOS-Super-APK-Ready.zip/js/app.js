const mods = {
  home: {
    title: "HOLOOS Home",
    html: `<h3>◉ Centro Holográfico</h3>
      <p>Hub principal del ecosistema. Acceso rápido a todos los módulos.</p>
      <button class="action" onclick="alert('Home activo')">Abrir Home</button>`
  },
  memory: {
    title: "Memory Graph",
    html: `<h3>🧠 Memory Graph</h3>
      <p>Preserva y conecta memorias. Continuidad de información y provenance.</p>
      <button class="action" onclick="alert('Memory Graph')">Abrir Memory</button>`
  },
  mobility: {
    title: "MobilityOS",
    html: `<h3>🚗 MobilityOS</h3>
      <p>Viaje, comida y entrega con asignación inteligente.</p>
      <button class="action" onclick="alert('MobilityOS')">Abrir Mobility</button>`
  },
  messenger: {
    title: "Messenger",
    html: `<h3>💬 Messenger</h3>
      <p>Mensajería con presencia holográfica conceptual.</p>
      <button class="action" onclick="alert('Messenger')">Abrir Messenger</button>`
  },
  ai: {
    title: "AI Assistant",
    html: `<h3>🤖 AI Assistant</h3>
      <p>Asistente inteligente integrado en el núcleo HOLOOS.</p>
      <button class="action" onclick="alert('AI Assistant')">Hablar con AI</button>`
  },
  spatial: {
    title: "Spatial XR",
    html: `<h3>🌐 Spatial XR</h3>
      <p>Runtime espacial para AR, VR y Mixed Reality.</p>
      <button class="action" onclick="alert('Spatial XR')">Entrar a Spatial</button>`
  },
  bio: {
    title: "Bio Engine",
    html: `<h3>🧬 Bio Engine</h3>
      <p>Fusión de sensores biométricos y percepción del entorno.</p>
      <button class="action" onclick="alert('Bio Engine')">Activar Bio</button>`
  },
  control: {
    title: "Panel de Control",
    html: `<h3>📡 Panel Operador</h3>
      <p>Centro de control: video, comunicaciones e IA. Módulo experimental.</p>
      <button class="action" onclick="alert('Panel de Control')">Abrir Control</button>`
  }
};

document.querySelectorAll('.card').forEach(btn => {
  btn.addEventListener('click', () => {
    const m = mods[btn.dataset.mod];
    if (!m) return;
    document.getElementById('panel-title').textContent = m.title;
    document.getElementById('panel-body').innerHTML = m.html;
    document.getElementById('panel').classList.remove('hidden');
  });
});

document.getElementById('panel-close').addEventListener('click', () => {
  document.getElementById('panel').classList.add('hidden');
});

document.getElementById('btn-ai').addEventListener('click', () => {
  document.querySelector('[data-mod="ai"]').click();
});

document.querySelectorAll('.nav-item').forEach(item => {
  item.addEventListener('click', () => {
    document.querySelectorAll('.nav-item').forEach(i => i.classList.remove('active'));
    item.classList.add('active');
    const t = item.dataset.tab;
    if (t === 'memory') document.querySelector('[data-mod="memory"]').click();
    if (t === 'ai') document.querySelector('[data-mod="ai"]').click();
    if (t === 'more') alert('Más módulos próximamente');
  });
});

if ('serviceWorker' in navigator) {
  navigator.serviceWorker.register('./sw.js').catch(() => {});
}
